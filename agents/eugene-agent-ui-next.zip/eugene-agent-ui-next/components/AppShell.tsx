"use client";

import { useMemo } from "react";
import {
  Alert,
  AlertIcon,
  Box,
  Flex,
  Heading,
  HStack,
  Text,
  VStack,
} from "@chakra-ui/react";
import { useChatStream } from "@/hooks/useChatStream";
import { useGraphExplorer } from "@/hooks/useGraphExplorer";
import { ChatPanel } from "./chat/ChatPanel";
import { KnowledgeGraph } from "./graph/KnowledgeGraph";
import { NodeDetailsPanel } from "./graph/NodeDetailsPanel";
import { EvidencePanel } from "./graph/EvidencePanel";
import { GraphToolbar } from "./graph/GraphToolbar";
import { GraphLegend } from "./graph/GraphLegend";
import { Sidebar } from "./Sidebar";

export function AppShell() {
  const {
    messages,
    graph,
    setGraph,
    extractor,
    pending,
    conversationId,
    tokenReady,
    error,
    send,
    cancel,
    resetConversation,
  } = useChatStream();

  const explorer = useGraphExplorer({ extractor, graph, setGraph });

  const nodeCount = graph.nodes.length;
  const edgeCount = graph.rels.length;

  const statusAlert = useMemo(
    () => error || explorer.error,
    [error, explorer.error]
  );

  return (
    <Flex h="100vh" w="100vw" overflow="hidden" bg="bg.canvas">
      <Box display={{ base: "none", lg: "block" }}>
        <Sidebar
          conversationId={conversationId}
          messageCount={messages.filter((m) => m.role !== "system").length}
          graphNodeCount={nodeCount}
          tokenReady={tokenReady}
          onNewConversation={() => {
            resetConversation();
            explorer.clearRoles();
            explorer.clearEvidence();
            explorer.setSelectedNodeId(null);
          }}
        />
      </Box>

      <ChatPanel
        messages={messages}
        pending={pending}
        ready={tokenReady}
        error={statusAlert}
        onSend={send}
        onCancel={cancel}
      />

      {/* --------- Right: Knowledge Graph panel ---------
          Layout:
            - Canvas fills the panel
            - Toolbar, stats chip, legend, detail/evidence drawers all FLOAT
              above the canvas as glass cards (Bessemer-style)
      */}
      <Flex
        direction="column"
        w={{ base: "0", md: "480px", xl: "640px" }}
        display={{ base: "none", md: "flex" }}
        borderLeft="1px solid"
        borderColor="border.subtle"
        bg="bg.canvas"
        minH={0}
        position="relative"
      >
        {/* --- Floating title card (top-left) --- */}
        <FloatingCard top={3} left={3}>
          <VStack align="flex-start" spacing={0}>
            <Heading size="sm" fontWeight={600}>
              Knowledge Graph
            </Heading>
            <Text fontSize="10px" color="text.muted">
              Interactive · right-click for actions
            </Text>
          </VStack>
        </FloatingCard>

        {/* --- Floating stats chip (top-right) --- */}
        <FloatingCard top={3} right={3} padded={false}>
          <Box px={3} py={1.5} fontSize="11px" color="text.muted">
            <Text as="span" color="text.primary" fontWeight={500}>
              {nodeCount}
            </Text>{" "}
            nodes ·{" "}
            <Text as="span" color="text.primary" fontWeight={500}>
              {edgeCount}
            </Text>{" "}
            edges
          </Box>
        </FloatingCard>

        {/* --- Floating toolbar (below title) --- */}
        <FloatingCard
          top="64px"
          left={3}
          right={3}
          padded={false}
          maxW="calc(100% - 24px)"
        >
          <GraphToolbar
            layout={explorer.layout}
            onLayoutChange={explorer.setLayout}
            source={explorer.source}
            sink={explorer.sink}
            onClearSource={explorer.clearSource}
            onClearSink={explorer.clearSink}
            onFindPath={explorer.runPathFinder}
            finding={explorer.findingPath}
            nodeCount={nodeCount}
            edgeCount={edgeCount}
            searchQuery={explorer.searchQuery}
            onSearchChange={explorer.setSearchQuery}
            allEdgeTypes={explorer.allEdgeTypes}
            hiddenEdgeTypes={explorer.hiddenEdgeTypes}
            onToggleEdgeType={explorer.toggleEdgeType}
            onFit={explorer.fit}
            onReset={explorer.resetGraph}
            onExpandAll={explorer.expandAll}
            onExportPng={explorer.exportPng}
          />
        </FloatingCard>

        {explorer.error && (
          <Alert
            status="warning"
            position="absolute"
            top="180px"
            left={3}
            right={3}
            zIndex={4}
            bg="signal.warning"
            color="surface.0"
            fontSize="xs"
            borderRadius="lg"
            py={1.5}
            px={4}
          >
            <AlertIcon boxSize="12px" />
            {explorer.error}
          </Alert>
        )}

        {/* --- Canvas fills everything --- */}
        <Box position="absolute" inset={0} overflow="hidden">
          <KnowledgeGraph
            graph={graph}
            layout={explorer.layout}
            selectedNodeId={explorer.selectedNodeId}
            highlightedPathNodeIds={explorer.highlightedPathNodeIds}
            searchQuery={explorer.searchQuery}
            hiddenEdgeTypes={explorer.hiddenEdgeTypes}
            onCyReady={explorer.setCyHandle}
            onSelectNode={explorer.setSelectedNodeId}
            onExpand={explorer.expand}
            onMarkSource={explorer.markSource}
            onMarkSink={explorer.markSink}
            onClearRoles={explorer.clearRoles}
            onShowEvidence={explorer.showEvidence}
            onTogglePin={explorer.togglePin}
            onRemove={explorer.removeNode}
          />
        </Box>

        <NodeDetailsPanel
          node={explorer.evidenceChain.length === 0 ? explorer.selectedNode : null}
          onClose={() => explorer.setSelectedNodeId(null)}
        />

        {explorer.evidenceChain.length > 0 && (
          <EvidencePanel
            chain={explorer.evidenceChain}
            onClose={explorer.clearEvidence}
          />
        )}

        {/* --- Floating legend (bottom) --- */}
        <FloatingCard
          bottom={3}
          left={3}
          right={3}
          padded={false}
          maxW="calc(100% - 24px)"
        >
          <GraphLegend />
        </FloatingCard>
      </Flex>
    </Flex>
  );
}

// ---------------------------------------------------------------------------
// Floating glass card primitive — used for all overlays on the graph canvas.
// ---------------------------------------------------------------------------

interface FloatingCardProps {
  children: React.ReactNode;
  top?: number | string;
  bottom?: number | string;
  left?: number | string;
  right?: number | string;
  maxW?: string;
  padded?: boolean;
}

function FloatingCard({
  children,
  top,
  bottom,
  left,
  right,
  maxW,
  padded = true,
}: FloatingCardProps) {
  return (
    <Box
      position="absolute"
      top={top}
      bottom={bottom}
      left={left}
      right={right}
      maxW={maxW}
      zIndex={3}
      bg="bg.glass"
      backdropFilter="saturate(160%) blur(18px)"
      border="1px solid"
      borderColor="border.muted"
      borderRadius="xl"
      boxShadow="0 12px 40px -20px rgba(0,0,0,0.5)"
      px={padded ? 3 : 0}
      py={padded ? 2 : 0}
      pointerEvents="auto"
    >
      {children}
    </Box>
  );
}
