/** @type {import('next').NextConfig} */
const nextConfig = {
  output: "standalone",
  reactStrictMode: true,
  // Cytoscape plugins are ESM-only
  transpilePackages: ["cytoscape-cola", "cytoscape-cxtmenu", "cytoscape-dagre"],
  experimental: {
    // Allow large SSE responses without buffering
    proxyTimeout: 600_000,
  },
  env: {
    NEXT_PUBLIC_APP_NAME: "Eugene",
  },
};

module.exports = nextConfig;
