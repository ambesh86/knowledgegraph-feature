import { extendTheme, type ThemeConfig } from "@chakra-ui/react";

const config: ThemeConfig = {
  initialColorMode: "dark",
  useSystemColorMode: false,
  disableTransitionOnChange: false,
};

/**
 * 2026 theme — "Biolume".
 * Dark-first. Glassmorphism surfaces. Iridescent violet/teal accent.
 * Inspired by Neo4j Aura context-graph UI but warmer for biomedical domain.
 */
const theme = extendTheme({
  config,
  fonts: {
    heading: `'Geist', 'Inter', ui-sans-serif, system-ui`,
    body: `'Geist', 'Inter', ui-sans-serif, system-ui`,
    mono: `'JetBrains Mono', 'Fira Code', ui-monospace, SFMono-Regular, monospace`,
  },
  colors: {
    surface: {
      0: "#07090f",
      50: "#0b0e16",
      100: "#11151f",
      200: "#171c28",
      300: "#1f2633",
      400: "#2a3242",
      500: "#3a4458",
    },
    ink: {
      50: "#f5f7fb",
      100: "#d9dfeb",
      200: "#aeb7cc",
      300: "#8a93ad",
      400: "#656f88",
      500: "#434c63",
    },
    accent: {
      50: "#eef1ff",
      100: "#d4daff",
      200: "#a5b0ff",
      300: "#7c8cff",
      400: "#5d70ff",
      500: "#3a4ff7",
      600: "#2c3dd6",
      700: "#212fa8",
      800: "#1a247f",
      900: "#121963",
    },
    lumen: {
      400: "#7fe7d4",
      500: "#3ecab4",
      600: "#23a591",
    },
    signal: {
      success: "#3ecab4",
      warning: "#f8c26b",
      danger: "#ff5d7a",
      info: "#7c8cff",
    },
  },
  semanticTokens: {
    colors: {
      "bg.canvas": { default: "surface.0", _light: "#f6f8fc" },
      "bg.panel": { default: "surface.100", _light: "#ffffff" },
      "bg.surface": { default: "surface.200", _light: "#eef2f8" },
      "bg.glass": {
        default: "rgba(17, 21, 31, 0.72)",
        _light: "rgba(255,255,255,0.85)",
      },
      "border.subtle": { default: "whiteAlpha.100", _light: "blackAlpha.100" },
      "border.muted": { default: "whiteAlpha.200", _light: "blackAlpha.200" },
      "text.primary": { default: "ink.50", _light: "#151a24" },
      "text.muted": { default: "ink.200", _light: "#606a80" },
      "accent.solid": { default: "accent.400", _light: "accent.500" },
    },
  },
  styles: {
    global: (props: { colorMode: "light" | "dark" }) => ({
      "html, body, #__next": {
        height: "100%",
        bg: "bg.canvas",
        color: "text.primary",
        fontFeatureSettings: `"cv02","cv03","cv04","cv11"`,
        transition: "background-color 200ms ease, color 200ms ease",
      },
      "::selection": { bg: "accent.500", color: "white" },
      "*::-webkit-scrollbar": { width: "8px", height: "8px" },
      "*::-webkit-scrollbar-thumb": {
        bg: props.colorMode === "dark" ? "whiteAlpha.200" : "blackAlpha.200",
        borderRadius: "full",
      },
      "*::-webkit-scrollbar-thumb:hover": {
        bg: props.colorMode === "dark" ? "whiteAlpha.400" : "blackAlpha.400",
      },
    }),
  },
  components: {
    Button: {
      defaultProps: { colorScheme: "accent" },
      baseStyle: { borderRadius: "xl", fontWeight: 500 },
    },
    Input: {
      defaultProps: { variant: "filled" },
    },
    Textarea: {
      defaultProps: { variant: "filled" },
    },
  },
});

export default theme;
